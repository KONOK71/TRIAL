<div align=center>
 
# ITS NETWORK BY LINTAR 21

<p>
 <img src="https://img.shields.io/github/stars/ItsMeLin/V13?color=%23DF0067&style=for-the-badge"/> &nbsp;
 <img src="https://img.shields.io/github/forks/ItsMeLin/V13?color=%239999FF&style=for-the-badge"/> &nbsp;
 <img src="https://img.shields.io/github/license/ItsMeLin/V13?color=%23E8E8E8&style=for-the-badge"/> &nbsp;
 
</p>

> Terminal only accepts ANSI color.<br>
> Username: 2<br>
> Password: 2<br>
<p align="center">  <a href="https://t.me/Lintar21"><img width="160" height="50" src="https://i.imgur.com/N7AK7XY.png"></a></p>
 
## Language</br>

 <img src="https://img.shields.io/badge/Python-FFDD00?style=for-the-badge&logo=python&logoColor=blue"/> <img src="https://img.shields.io/badge/JavaScript-323330?style=for-the-badge&logo=javascript&logoColor=F7DF1E"/> <img src="https://img.shields.io/badge/Perl-39457E?style=for-the-badge&logo=perl&logoColor=white"/> <img src="https://img.shields.io/badge/C-00599C?style=for-the-badge&logo=c&logoColor=white"/> <img src="https://img.shields.io/badge/Go-00ADD8?style=for-the-badge&logo=go&logoColor=white"/>
 </div>
 
 ## Logs</br>
- FUCKING YOURSELF

 
## Screenshot
- I FORGOT TO SCREENSHOT MY POWER BECAUSE I WAS BUSY!!

# Tree
* [Read now pls](#README)
* [Info](#Info)
* [Setup](#Setup)
* [Credits](#Credits)
* [T.O.S](#TOS)
* [Contact](#Contact)

# README ♥️
Heyyoooo Bitch You Better Give Me a Star

# Info
- [x] Open Source
- [x] Powerful
- [x] Simple


# Setup
YOU STUPID FIND OUT FOR YOURSELF!

# Credits
Why do you know bastards?
# TOS:
```sh
║ 2. Do not attack  go.id ac.id .gov domains  ║
║ 4. Only attack stress testing servers         ║
║ 5. Don't skid the panel                       ║
║ 6. Give a star to the github repository       ║
║ 7. The creator does not do any harm           |
don't do these things. if you can lol
```

# CONTACT:
```sh
Telegram: @Lintar21
Whatsapp: +6281247891005

```
